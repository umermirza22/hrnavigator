# # routes/chat_handler.py
# from fastapi import APIRouter, Request, Header, HTTPException
# from typing import List, Dict, Any, Optional
# import json
# import re

# # Freshdesk service: import robustly with fallbacks
# try:
#     from services.freshdesk_service import (
#         fetch_user_tickets,
#         fetch_ticket_by_id,
#         summarize_tickets_for_chat,
#     )
# except Exception:
#     # Minimal fallbacks if only fetch_user_tickets exists
#     from services.freshdesk_service import fetch_user_tickets  # type: ignore

#     def fetch_ticket_by_id(ticket_id: int) -> Optional[Dict[str, Any]]:  # fallback
#         return None

#     def summarize_tickets_for_chat(tickets: List[Dict[str, Any]]) -> str:  # fallback
#         if not tickets:
#             return "No tickets found."
#         counts: Dict[str, int] = {}
#         for t in tickets:
#             s = str(t.get("status") or "Unknown")
#             counts[s] = counts.get(s, 0) + 1
#         parts = [f"{k}: {v}" for k, v in counts.items()]
#         subjects = [f"#{t.get('id')} – {t.get('subject','(no subject)')}" for t in tickets[:3]]
#         summary = " | ".join(parts) if parts else ""
#         recent = "; ".join(subjects) if subjects else ""
#         return (summary + (". Recent: " + recent if recent else "")) or "No tickets found."

# from services.query_orchestrator import answer_query  # tabular-first, RAG fallback
# from services.conversation_memory import add_message, get_history

# from langchain_community.chat_models import ChatOpenAI
# from langchain.schema import SystemMessage, HumanMessage, AIMessage

# router = APIRouter()

# # ---------------- LLM system prompts ----------------

# # 1) Top-level router: choose {ticket, chitchat, hr}
# _CLASSIFIER_SYS = """You are a router for an HR assistant. Classify the user's last message into EXACTLY one of:
# - "ticket"     → anything about support tickets, case IDs, Freshdesk (status, list, count, search, details).
# - "chitchat"   → greetings, thanks, small talk ("hi", "how are you", "ok", "thanks", "bye", etc.)
# - "hr"         → everything else (personal HR data from tables or general HR policy from documents).
# Return ONLY strict JSON: {"route": "ticket|chitchat|hr", "reason": "<very brief>"}.
# No extra text.
# """

# # 2) Chit-chat generator: friendly, no sources, brief
# _CHITCHAT_SYS = """You are a friendly HR assistant. The user is chit-chatting.
# Reply naturally in 1–2 sentences. Do NOT reference documents, sources, IDs, or data.
# Be warm and concise. If they say thanks, acknowledge and invite further questions.
# """

# # 3) Freshdesk planner: turn NL into an execution plan
# # Supported ops:
# #   - list_user_tickets: list/summarize this user's tickets (optionally by status or recent)
# #   - get_ticket_by_id: fetch a single ticket by numeric ID
# #   - search_user_tickets: search this user's tickets by subject text
# #   - count_by_status: count this user's tickets by a specific status
# #   - summary: produce a brief status distribution + most recent subjects
# _FD_PLANNER_SYS = """You are a planner for Freshdesk actions. Convert the user's request into a STRICT JSON plan.
# Allowed ops:
#   - "list_user_tickets"
#   - "get_ticket_by_id"
#   - "search_user_tickets"
#   - "count_by_status"
#   - "summary"

# Parameters:
#   - "ticket_id": integer (when asking about a specific ticket number)
#   - "status": string (e.g., "Open", "Pending", "Resolved", "Closed"; case-insensitive)
#   - "subject_contains": string (text to search in subject; case-insensitive)
#   - "limit": integer (how many tickets to show, default 5)
#   - "result_type": "scalar" | "table" | "summary"

# Rules:
# - If the user references a specific ticket number (e.g., "ticket 1234"), choose "get_ticket_by_id".
# - If the user asks for count by status (e.g., "how many open tickets"), choose "count_by_status".
# - If the user wants recent/overview, choose "summary".
# - If the user wants to see their tickets (or with a status filter), choose "list_user_tickets".
# - If the user mentions keywords to find a specific ticket by topic, choose "search_user_tickets" with "subject_contains".
# - Always return a valid JSON object and nothing else.
# - If the request is ambiguous, prefer "summary".

# Return JSON like:
# {
#   "op": "<one of the allowed ops>",
#   "ticket_id": 0,
#   "status": "",
#   "subject_contains": "",
#   "limit": 5,
#   "result_type": "scalar|table|summary",
#   "reason": "<very brief>"
# }
# """


# # ---------------- LLM helpers ----------------

# def _llm_zero() -> ChatOpenAI:
#     return ChatOpenAI(temperature=0)

# def _llm_chat() -> ChatOpenAI:
#     return ChatOpenAI(temperature=0.3)

# def _to_langchain_history(hist: List[dict]) -> List:
#     msgs = []
#     for m in hist[-10:]:  # last 10 messages only
#         role = (m.get("role") or "").lower()
#         content = m.get("content") or ""
#         if role == "user":
#             msgs.append(HumanMessage(content=content))
#         else:
#             msgs.append(AIMessage(content=content))
#     return msgs

# def _classify_route(user_email: str, message: str) -> str:
#     llm = _llm_zero()
#     sys = SystemMessage(content=_CLASSIFIER_SYS)
#     usr = HumanMessage(content=f"User: {user_email or 'unknown'}\nMessage: {message}")
#     out = llm.invoke([sys, usr]).content or ""
#     s, e = out.find("{"), out.rfind("}")
#     route = "hr"
#     if s != -1 and e != -1:
#         try:
#             obj = json.loads(out[s:e+1])
#             r = str(obj.get("route", "hr")).strip().lower()
#             if r in {"ticket", "chitchat", "hr"}:
#                 route = r
#         except Exception:
#             pass
#     return route

# def _answer_chitchat(user_email: str, message: str) -> str:
#     llm = _llm_chat()
#     sys = SystemMessage(content=_CHITCHAT_SYS)
#     hist_msgs = _to_langchain_history(get_history(user_email))
#     usr = HumanMessage(content=message)
#     resp = llm.invoke([sys, *hist_msgs, usr]).content or "Happy to help!"
#     return resp.strip()

# def _plan_freshdesk(user_email: str, message: str) -> Dict[str, Any]:
#     """
#     Use LLM to produce a Freshdesk plan (op + parameters).
#     """
#     llm = _llm_zero()
#     sys = SystemMessage(content=_FD_PLANNER_SYS)
#     hist_msgs = _to_langchain_history(get_history(user_email))
#     usr = HumanMessage(content=f"User email: {user_email}\nRequest: {message}")
#     out = llm.invoke([sys, *hist_msgs, usr]).content or ""
#     s, e = out.find("{"), out.rfind("}")
#     plan = {
#         "op": "summary",
#         "ticket_id": 0,
#         "status": "",
#         "subject_contains": "",
#         "limit": 5,
#         "result_type": "summary",
#         "reason": "fallback",
#     }
#     if s != -1 and e != -1:
#         try:
#             obj = json.loads(out[s:e+1])
#             plan.update({k: obj.get(k, plan.get(k)) for k in plan.keys()})
#         except Exception:
#             pass
#     # normalize types
#     try:
#         plan["ticket_id"] = int(plan.get("ticket_id") or 0)
#     except Exception:
#         plan["ticket_id"] = 0
#     try:
#         plan["limit"] = max(1, min(50, int(plan.get("limit") or 5)))
#     except Exception:
#         plan["limit"] = 5
#     if plan.get("result_type") not in {"scalar", "table", "summary"}:
#         plan["result_type"] = "summary"
#     return plan

# # ---------------- Freshdesk execution helpers ----------------

# def _filter_tickets(
#     tickets: List[Dict[str, Any]],
#     status: Optional[str] = None,
#     subject_contains: Optional[str] = None,
#     limit: int = 5,
# ) -> List[Dict[str, Any]]:
#     res = tickets
#     if status:
#         s = status.strip().lower()
#         res = [t for t in res if str(t.get("status","")).strip().lower() == s]
#     if subject_contains:
#         q = subject_contains.strip().lower()
#         res = [t for t in res if q in str(t.get("subject","")).lower()]
#     return res[:limit] if limit else res

# def _format_ticket_row(t: Dict[str, Any]) -> str:
#     return f"#{t.get('id')} – {t.get('subject','(no subject)')}  [{t.get('status','Unknown')}]  updated: {t.get('updated','-')}"

# def _execute_freshdesk_plan(user_email: str, plan: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Execute the Freshdesk plan using available service functions.
#     Returns a dict with 'answer' (concise), 'natural' (friendly), 'intent' ('ticket'),
#     and optional 'sources' (usually empty for tickets).
#     """
#     op = plan.get("op", "summary")
#     limit = int(plan.get("limit") or 5)
#     status = (plan.get("status") or "").strip()
#     subject_contains = (plan.get("subject_contains") or "").strip()
#     ticket_id = int(plan.get("ticket_id") or 0)

#     if not user_email:
#         raise HTTPException(status_code=400, detail="Email is required for Freshdesk queries")

#     # Pull user's tickets once for list/search/count ops
#     if op in {"list_user_tickets", "search_user_tickets", "count_by_status", "summary"}:
#         tickets = fetch_user_tickets(user_email)

#     # Operation handlers
#     if op == "get_ticket_by_id" and ticket_id > 0:
#         t = fetch_ticket_by_id(ticket_id)
#         if not t:
#             return {"answer": "No such ticket.", "natural": f"Ticket #{ticket_id} was not found.", "intent": "ticket", "sources": []}
#         natural = (
#             f"Ticket #{t.get('id')}: {t.get('subject','(no subject)')} "
#             f"[{t.get('status','Unknown')}] last updated {t.get('updated','-')}."
#         )
#         return {"answer": json.dumps(t), "natural": natural, "intent": "ticket", "sources": []}

#     if op == "count_by_status":
#         filtered = _filter_tickets(tickets, status=status)
#         cnt = len(filtered)
#         st = status or "all statuses"
#         return {"answer": str(cnt), "natural": f"You have {cnt} ticket(s) in {st}.", "intent": "ticket", "sources": []}

#     if op == "search_user_tickets":
#         filtered = _filter_tickets(tickets, status=status, subject_contains=subject_contains, limit=limit)
#         if not filtered:
#             return {"answer": "0", "natural": "No matching tickets found.", "intent": "ticket", "sources": []}
#         lines = "\n".join(_format_ticket_row(t) for t in filtered)
#         return {"answer": str(len(filtered)), "natural": lines, "intent": "ticket", "sources": []}

#     if op == "list_user_tickets":
#         filtered = _filter_tickets(tickets, status=status, limit=limit)
#         if not filtered:
#             return {"answer": "0", "natural": "No tickets found.", "intent": "ticket", "sources": []}
#         lines = "\n".join(_format_ticket_row(t) for t in filtered)
#         return {"answer": str(len(filtered)), "natural": lines, "intent": "ticket", "sources": []}

#     # default or "summary"
#     summary = summarize_tickets_for_chat(tickets)
#     return {"answer": summary, "natural": summary, "intent": "ticket", "sources": []}

# # ---------------- /chat ----------------

# @router.post("/")  # POST /chat  { "email": "...", "message": "..." }
# async def handle_user_query(request: Request):
#     try:
#         payload = await request.json()
#     except Exception:
#         raise HTTPException(status_code=400, detail="Invalid JSON body")

#     user_email = (payload.get("email") or "").strip().lower()
#     message = (payload.get("message") or "").strip()
#     if not message:
#         raise HTTPException(status_code=400, detail="Field 'message' is required")

#     # Store user message
#     add_message(user_email, "user", message)

#     # LLM: route → {ticket | chitchat | hr}
#     route = _classify_route(user_email, message)

#     # 1) Freshdesk via LLM plan + execution
#     if route == "ticket":
#         plan = _plan_freshdesk(user_email, message)
#         result = _execute_freshdesk_plan(user_email, plan)
#         add_message(user_email, "assistant", result.get("natural", result.get("answer","")))
#         return {
#             "response": result.get("answer", ""),
#             "natural": result.get("natural", result.get("answer","")),
#             "intent": result.get("intent", "ticket"),
#             "email_used": user_email,
#             "sources": [],  # no references for ticket responses
#             "plan": plan,   # useful for debugging while developing
#         }

#     # 2) Chit-chat → no references
#     if route == "chitchat":
#         reply = _answer_chitchat(user_email, message)
#         add_message(user_email, "assistant", reply)
#         return {
#             "response": reply,
#             "natural": reply,
#             "intent": "chitchat",
#             "email_used": user_email,
#         }

#     # 3) HR (tabular plan → pandas; else RAG on policies)
#     result = answer_query(message, email=user_email or None)
#     answer = result.get("answer", "")
#     natural = result.get("natural", answer)
#     intent = result.get("intent")

#     add_message(user_email, "assistant", natural)

#     return {
#         "response": answer,         # concise value (e.g., "20")
#         "natural": natural,         # friendly sentence
#         "intent": intent,           # "tabular" or "general_policy"
#         "email_used": user_email,
#         "sources": result.get("sources", []),
#     }

# # ---------------- /api/messages (Microsoft Teams) ----------------

# teams_router = APIRouter()

# @teams_router.post("/api/messages")
# async def handle_teams_message(request: Request, authorization: str = Header(default=None)):
#     body = await request.json()

#     if (body.get("type") or "") != "message":
#         return {"status": "ignored", "reason": f"activity_type={body.get('type')}"}

#     text = (body.get("text") or "").strip()

#     from_obj = body.get("from", {}) or {}
#     channel_data = body.get("channelData", {}) or {}
#     user_email = (
#         (channel_data.get("email") or "").strip().lower()
#         or (from_obj.get("userPrincipalName") or "")
#         or (from_obj.get("aadObjectId") or "")
#         or (from_obj.get("id") or "")
#         or "demo.user@company.com"
#     )

#     add_message(user_email, "user", text)

#     route = _classify_route(user_email, text)

#     if route == "ticket":
#         plan = _plan_freshdesk(user_email, text)
#         result = _execute_freshdesk_plan(user_email, plan)
#         reply = result.get("natural") or result.get("answer","")
#         add_message(user_email, "assistant", reply)
#         return {"type": "message", "text": reply}

#     if route == "chitchat":
#         reply = _answer_chitchat(user_email, text)
#         add_message(user_email, "assistant", reply)
#         return {"type": "message", "text": reply}

#     # HR path → tabular or policy
#     result = answer_query(text, email=user_email or None)
#     answer = result.get("natural") or result.get("answer", "")
#     srcs = result.get("sources", [])

#     add_message(user_email, "assistant", answer)

#     if srcs:
#         lines = []
#         for s in srcs:
#             src = s.get("source") or s.get("filename") or "source"
#             page = s.get("page")
#             lines.append(f"- {src}{f' (page {page})' if page is not None else ''}")
#         answer += "\n\nSources:\n" + "\n".join(lines)

#     return {"type": "message", "text": answer}
# routes/chat_handler.py
from fastapi import APIRouter, Request, Header, HTTPException
from typing import List, Dict, Any, Optional
import json

from services.conversation_memory import add_message, get_history
from services.tabular_query_service import answer_tabular  # updated signature below
from services.rag_policy_service import answer_policy_only  # new helper added below
# Freshdesk helpers reused from your existing code
from services.freshdesk_service import (
    fetch_user_tickets,
    fetch_ticket_by_id,
    summarize_tickets_for_chat,
)

from langchain_community.chat_models import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage, AIMessage

router = APIRouter()

# ---------- Freshdesk planning via LLM (kept lightweight) ----------
_FD_PLANNER_SYS = """You are a planner for Freshdesk actions. Convert the user's request into a STRICT JSON plan.
Allowed ops: "list_user_tickets", "get_ticket_by_id", "search_user_tickets", "count_by_status", "summary"
Return JSON:
{"op":"...","ticket_id":0,"status":"","subject_contains":"","limit":5,"result_type":"scalar|table|summary"}"""

def _llm_zero() -> ChatOpenAI:
    return ChatOpenAI(temperature=0)

def _plan_freshdesk(user_email: str, message: str) -> Dict[str, Any]:
    llm = _llm_zero()
    sys = SystemMessage(content=_FD_PLANNER_SYS)
    usr = HumanMessage(content=f"User: {user_email}\nRequest: {message}")
    out = llm.invoke([sys, usr]).content or ""
    s, e = out.find("{"), out.rfind("}")
    plan = {"op":"summary","ticket_id":0,"status":"","subject_contains":"","limit":5,"result_type":"summary"}
    if s != -1 and e != -1:
        try:
            obj = json.loads(out[s:e+1])
            plan.update({k: obj.get(k, plan.get(k)) for k in plan.keys()})
        except Exception:
            pass
    # normalize
    try: plan["ticket_id"] = int(plan.get("ticket_id") or 0)
    except: plan["ticket_id"] = 0
    try: plan["limit"] = max(1, min(50, int(plan.get("limit") or 5)))
    except: plan["limit"] = 5
    if plan.get("result_type") not in {"scalar","table","summary"}:
        plan["result_type"] = "summary"
    return plan

def _filter_tickets(tix: List[Dict[str,Any]], status: Optional[str], subject_contains: Optional[str], limit: int):
    res = tix
    if status:
        s = status.strip().lower()
        res = [t for t in res if str(t.get("status","")).strip().lower()==s]
    if subject_contains:
        q = subject_contains.strip().lower()
        res = [t for t in res if q in str(t.get("subject","")).lower()]
    return res[:limit] if limit else res

def _exec_freshdesk(user_email: str, plan: Dict[str,Any]) -> Dict[str,Any]:
    if not user_email:
        raise HTTPException(status_code=400, detail="Email is required for ticket queries")

    op = plan.get("op","summary")
    limit = int(plan.get("limit") or 5)
    status = (plan.get("status") or "").strip()
    subject_contains = (plan.get("subject_contains") or "").strip()
    ticket_id = int(plan.get("ticket_id") or 0)

    if op == "get_ticket_by_id" and ticket_id > 0:
        t = fetch_ticket_by_id(ticket_id)
        if not t:
            return {"answer":"No such ticket.", "natural":f"Ticket #{ticket_id} was not found.", "intent":"ticket", "sources":[]}
        natural = f"Ticket #{t.get('id')}: {t.get('subject','(no subject)')} [{t.get('status','Unknown')}] last updated {t.get('updated','-')}."
        return {"answer": json.dumps(t), "natural": natural, "intent": "ticket", "sources": []}

    # For list/search/count/summary pull once
    tickets = fetch_user_tickets(user_email)
    if op == "count_by_status":
        cnt = len(_filter_tickets(tickets, status=status, subject_contains=None, limit=99999))
        st = status or "all statuses"
        return {"answer": str(cnt), "natural": f"You have {cnt} ticket(s) in {st}.", "intent": "ticket", "sources": []}

    if op == "search_user_tickets":
        filtered = _filter_tickets(tickets, status=status, subject_contains=subject_contains, limit=limit)
        if not filtered:
            return {"answer":"0","natural":"No matching tickets found.","intent":"ticket","sources":[]}
        lines = "\n".join(f"#{t['id']} – {t.get('subject','(no subject)')} [{t.get('status','Unknown')}] updated: {t.get('updated','-')}" for t in filtered)
        return {"answer": str(len(filtered)), "natural": lines, "intent": "ticket", "sources": []}

    if op == "list_user_tickets":
        filtered = _filter_tickets(tickets, status=status, subject_contains=None, limit=limit)
        if not filtered:
            return {"answer":"0","natural":"No tickets found.","intent":"ticket","sources":[]}
        lines = "\n".join(f"#{t['id']} – {t.get('subject','(no subject)')} [{t.get('status','Unknown')}] updated: {t.get('updated','-')}" for t in filtered)
        return {"answer": str(len(filtered)), "natural": lines, "intent": "ticket", "sources": []}

    # default → summary
    summary = summarize_tickets_for_chat(tickets)
    return {"answer": summary, "natural": summary, "intent": "ticket", "sources": []}

# ---------- /chat ----------
@router.post("/")  # body: { email, message, mode }
async def handle_user_query(request: Request):
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    user_email = (payload.get("email") or "").strip().lower()
    message = (payload.get("message") or "").strip()
    mode = (payload.get("mode") or "policy").strip().lower()   # NEW: policy|vacation|wfh|ticket

    if not message:
        raise HTTPException(status_code=400, detail="Field 'message' is required")

    # Store user message for short contextual chit-chat continuity (no more than last 10)
    add_message(user_email, "user", message)

    # -------------------- explicit routing by mode --------------------
    if mode == "ticket":
        plan = _plan_freshdesk(user_email, message)
        result = _exec_freshdesk(user_email, plan)
        reply = result.get("natural") or result.get("answer") or "Okay."
        add_message(user_email, "assistant", reply)
        return {
            "response": result.get("answer",""),
            "natural": reply,
            "intent": "ticket",
            "email_used": user_email,
            "sources": [],
            "plan": plan
        }

    if mode in {"vacation","wfh"}:
        if not user_email:
            raise HTTPException(status_code=400, detail="Email is required for this tab")
        # Only read the *selected* CSV; never scan all tables unless explicitly allowed
        res = answer_tabular(question=message, user_email=user_email, dataset_hint=mode, allow_all_tables=False)
        reply = res.get("natural") or res.get("answer") or "No matching rows."
        add_message(user_email, "assistant", reply)
        return {
            "response": res.get("answer",""),
            "natural": reply,
            "intent": "tabular",
            "email_used": user_email,
            "sources": [{"source": res.get("source")} if res.get("source") else {}],
        }

    # DEFAULT: policy/documents only (RAG) — no CSV, no Freshdesk
    result = answer_policy_only(message, k=4)
    reply = result.get("answer","")
    add_message(user_email, "assistant", reply)
    return {
        "response": reply,
        "natural": reply,
        "intent": "general_policy",
        "email_used": user_email,
        "sources": result.get("sources", []),  # filenames/pages shown on UI
    }
