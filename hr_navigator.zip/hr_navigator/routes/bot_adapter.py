# # bot_adapter.py
# import os
# import time
# import json
# import requests

# APP_ID = os.getenv("MICROSOFT_APP_ID", "")
# APP_PASSWORD = os.getenv("MICROSOFT_APP_PASSWORD", "")
# TENANT = (os.getenv("MICROSOFT_TENANT_ID") or "botframework.com").strip()

# _session = requests.Session()
# _token_cache = {"access_token": None, "exp": 0}

# def _token_url() -> str:
#     # If your app is single-tenant, we use your tenant; else botframework.com
#     return f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/token"

# def _get_app_token() -> str:
#     now = time.time()
#     if _token_cache["access_token"] and _token_cache["exp"] - now > 60:
#         return _token_cache["access_token"]

#     if not APP_ID or not APP_PASSWORD:
#         raise RuntimeError("MICROSOFT_APP_ID / MICROSOFT_APP_PASSWORD missing")

#     data = {
#         "grant_type": "client_credentials",
#         "client_id": APP_ID,
#         "client_secret": APP_PASSWORD,
#         "scope": "https://api.botframework.com/.default",
#     }
#     r = _session.post(_token_url(), data=data, timeout=15)
#     try:
#         r.raise_for_status()
#     except requests.HTTPError as e:
#         raise RuntimeError(f"Token fetch failed ({r.status_code}): {r.text}") from e

#     j = r.json()
#     _token_cache["access_token"] = j["access_token"]
#     _token_cache["exp"] = now + int(j.get("expires_in", 3600))
#     return _token_cache["access_token"]

# def _post_activity(activity: dict, payload: dict) -> requests.Response:
#     """Post an activity (message/typing) to this conversation with required fields."""
#     token = _get_app_token()

#     service_url = (activity.get("serviceUrl") or "").rstrip("/")
#     conversation_id = ((activity.get("conversation") or {}).get("id") or "").strip()
#     if not service_url or not conversation_id:
#         raise RuntimeError(f"Missing serviceUrl/conversation in activity: {json.dumps(activity)[:400]}")

#     # REQUIRED: set 'from' to the bot identity (what the channel knows as the bot)
#     bot_identity = activity.get("recipient") or {}
#     user_identity = activity.get("from") or {}

#     body = {
#         **payload,
#         "from": bot_identity,     # <- fixes 'Activity.From' required
#         "recipient": user_identity,  # optional but good for some channels
#     }

#     # If you want to reply-to the specific user message id (optional)
#     reply_to = (activity.get("id") or "").strip()
#     if reply_to and body.get("type") == "message":
#         body["replyToId"] = reply_to

#     url = f"{service_url}/v3/conversations/{conversation_id}/activities"
#     headers = {
#         "Authorization": f"Bearer {token}",
#         "Content-Type": "application/json",
#     }

#     # DEBUG (optional): print the body once to verify 'from' is present
#     # print(">>> OUTBOUND BODY:", json.dumps(body, indent=2)[:1000])

#     resp = _session.post(url, headers=headers, json=body, timeout=15)
#     return resp

# def send_typing(activity: dict) -> None:
#     try:
#         resp = _post_activity(activity, {"type": "typing"})
#         if resp.status_code == 401:
#             _token_cache.update({"access_token": None, "exp": 0})
#             _post_activity(activity, {"type": "typing"})
#     except Exception:
#         pass

# def send_reply(activity: dict, text: str) -> tuple[int, str]:
#     resp = _post_activity(activity, {"type": "message", "text": text})
#     if resp.status_code == 401:
#         _token_cache.update({"access_token": None, "exp": 0})
#         resp = _post_activity(activity, {"type": "message", "text": text})
#     return resp.status_code, resp.text




# bot_adapter.py
import os
import time
import json
import requests
from urllib.parse import urlparse

APP_ID = os.getenv("MICROSOFT_APP_ID", "")
APP_PASSWORD = os.getenv("MICROSOFT_APP_PASSWORD", "")
# Keep tenant default to 'botframework.com' unless you KNOW you need another
TENANT = (os.getenv("MICROSOFT_TENANT_ID") or "botframework.com").strip()

_session = requests.Session()
# cache token PER SCOPE (important when clouds differ)
_token_cache = {}  # {scope: {"access_token": str, "exp": epoch_float}}

def _token_url() -> str:
    return f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/token"

def _scope_for_service_url(service_url: str) -> str:
    """
    Pick the correct OAuth scope by cloud.
    """
    host = (urlparse(service_url).hostname or "").lower()
    # US Gov clouds
    if host.endswith(".botframework.us"):
        return "https://api.botframework.us/.default"
    # China cloud
    if host.endswith(".azure.cn") or "botframework.azure.cn" in host:
        return "https://api.botframework.azure.cn/.default"
    # Public cloud (Teams)
    return "https://api.botframework.com/.default"

def _get_app_token(scope: str) -> str:
    now = time.time()
    cached = _token_cache.get(scope)
    if cached and cached["access_token"] and cached["exp"] - now > 60:
        return cached["access_token"]

    if not APP_ID or not APP_PASSWORD:
        raise RuntimeError("MICROSOFT_APP_ID / MICROSOFT_APP_PASSWORD missing")

    data = {
        "grant_type": "client_credentials",
        "client_id": APP_ID,
        "client_secret": APP_PASSWORD,
        "scope": scope,
    }
    r = _session.post(_token_url(), data=data, timeout=15)
    try:
        r.raise_for_status()
    except requests.HTTPError as e:
        raise RuntimeError(f"Token fetch failed ({r.status_code}): {r.text}") from e

    j = r.json()
    _token_cache[scope] = {
        "access_token": j["access_token"],
        "exp": now + int(j.get("expires_in", 3600)),
    }
    return _token_cache[scope]["access_token"]

def _post_activity(activity: dict, payload: dict) -> requests.Response:
    """Post an activity (message/typing) back into this conversation."""
    service_url = (activity.get("serviceUrl") or "").rstrip("/")
    conversation_id = ((activity.get("conversation") or {}).get("id") or "").strip()
    if not service_url or not conversation_id:
        raise RuntimeError(f"Missing serviceUrl/conversation in activity: {json.dumps(activity)[:400]}")

    scope = _scope_for_service_url(service_url)
    token = _get_app_token(scope)

    bot_identity = activity.get("recipient") or {}
    user_identity = activity.get("from") or {}

    body = {
        **payload,
        "from": bot_identity,       # REQUIRED
        "recipient": user_identity, # good practice
        # You can also include channelData/tenant here when starting NEW conversations.
    }

    reply_to = (activity.get("id") or "").strip()
    if reply_to and body.get("type") == "message":
        body["replyToId"] = reply_to

    url = f"{service_url}/v3/conversations/{conversation_id}/activities"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    resp = _session.post(url, headers=headers, json=body, timeout=15)

    # Auto-refresh on 401 once
    if resp.status_code == 401:
        # drop this scope's cache and retry
        _token_cache.pop(scope, None)
        token = _get_app_token(scope)
        headers["Authorization"] = f"Bearer {token}"
        resp = _session.post(url, headers=headers, json=body, timeout=15)

    return resp

def send_typing(activity: dict) -> None:
    try:
        _post_activity(activity, {"type": "typing"})
    except Exception:
        pass

def send_reply(activity: dict, text: str) -> tuple[int, str]:
    resp = _post_activity(activity, {"type": "message", "text": text})
    return resp.status_code, resp.text
