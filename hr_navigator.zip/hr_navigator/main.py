# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.responses import FileResponse
# from pathlib import Path

# from routes.chat_handler import router as chat_router
# # ,teams_router
# from routes.policies import router as policies_router
# from routes.team_messages import router as teams_router



# app = FastAPI(title="HR Navigator Demo")

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],          # Caution: Tighten in production!
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Manual testing route
# app.include_router(chat_router, prefix="/chat", tags=["HR Bot (manual)"])

# # Teams endpoint
# app.include_router(teams_router, tags=["Teams"])  # exposes POST /api/messages



# # Policy upload, reindex, and query endpoints
# app.include_router(policies_router, tags=["Policies"])

# @app.get("/")
# def health():
#     return {"status": "ok", "service": "hr-navigator"}

# @app.get("/test-client")
# def get_test_client():
#     """Serve the test client HTML for manual testing."""
#     html_path = Path("templates") / "test_client.html"
#     return FileResponse(html_path)





# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from routes.chat_handler import router as chat_router
from routes.policies import router as policies_router
from routes.team_messages import router as teams_router

BASE_DIR = Path(__file__).resolve().parent
PUBLIC_DIR = BASE_DIR / "public"

app = FastAPI(title="HR Navigator Demo")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # tighten in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve small Markdown previews at /public/md/...
PUBLIC_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/public", StaticFiles(directory=str(PUBLIC_DIR)), name="public")

# Manual testing route
app.include_router(chat_router, prefix="/chat", tags=["HR Bot (manual)"])

# Teams endpoint
app.include_router(teams_router, tags=["Teams"])

# Policy upload, reindex, and query endpoints
app.include_router(policies_router, tags=["Policies"])

@app.get("/")
def health():
    return {"status": "ok", "service": "hr-navigator"}

@app.get("/test-client")
def get_test_client():
    """Serve the test client HTML for manual testing."""
    html_path = Path("templates") / "test_client.html"
    return FileResponse(html_path)
