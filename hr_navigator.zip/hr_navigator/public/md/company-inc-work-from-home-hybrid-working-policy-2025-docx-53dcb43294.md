# Company Inc Work From Home (Hybrid Working) Policy 2025.docx

_Modified: 2025-08-15T06:06:59.264493_

---

The Employee Assistance Programme (if applicable) is available for confidential support.

14. Temporary Changes & Business Continuity

The Company may temporarily vary hybrid arrangements in response to emergencies, health & safety concerns, client requirements or business continuity events.

Employees must be able to attend the office when reasonably required, including at short notice where necessary.

15. NonCompliance

Breaches of this Policy may result in withdrawal of hybrid working approval and/or disciplinary action in line with the Disciplinary Policy.

16. Review & Contact

This Policy will be reviewed annually or upon material change in law, regulation or business need.
Questions should be directed to HR (People Operations).

Employee Acknowledgement

I acknowledge that I have read, understood and agree to comply with the Work From Home (Hybrid Working) Policy.

Employee Name: ____________________________ Signature: ____________________________ Date: _____________