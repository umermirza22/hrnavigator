import json

def load_hr_data():
    with open("data/hr_users.json") as f:
        return json.load(f)

def get_user_profile(email):
    users = load_hr_data()
    return users.get(email, {})

def get_vacation_days(profile):
    return profile.get("remaining_holidays", "N/A")
