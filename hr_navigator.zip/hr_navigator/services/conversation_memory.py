# services/conversation_memory.py
from collections import deque
from typing import Deque, Dict, List, Literal, Optional

# Keep the last 20 messages (≈10 user/assistant turns)
_MAX_MESSAGES = 20

# In-memory store: { user_id (email or "_anon") : deque([{role, content}, ...]) }
_store: Dict[str, Deque[dict]] = {}

Role = Literal["user", "assistant"]

def _key(user_id: Optional[str]) -> str:
    return (user_id or "_anon").strip().lower() or "_anon"

def add_message(user_id: Optional[str], role: Role, content: str) -> None:
    """Append one message to the user's history, trimming to the last N messages."""
    k = _key(user_id)
    if k not in _store:
        _store[k] = deque(maxlen=_MAX_MESSAGES)
    _store[k].append({"role": role, "content": content})

def get_history(user_id: Optional[str]) -> List[dict]:
    """Return a shallow copy of the recent history for this user (for context/debug)."""
    return list(_store.get(_key(user_id), []))

def clear_history(user_id: Optional[str]) -> None:
    """Clear a user's history (optional utility)."""
    _store.pop(_key(user_id), None)
