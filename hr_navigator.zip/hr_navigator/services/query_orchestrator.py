# # services/query_orchestrator.py
# """
# Unified HR query orchestrator (NO Freshdesk API)

# - Friendly, concise responses (no static openers)
# - Maintains conversation flow (last 12 messages)
# - Personal HR data from CSV (tabular) when applicable
# - Policy answers via RAG embeddings
# - Ticket questions answered ONLY from embedded tickets knowledge (no external API)
# - Proper ticket counts via JSON parsing and status aggregation
# - Clean, clickable References; skip for small talk
# - NEW: Strip LLM-injected 'References:' block to avoid duplication
# - NEW: Relevance-filter and dedupe references based on user query/topic
# """

# import json
# import re
# import os
# from typing import Optional, Dict, Any, List, Tuple

# from langchain_openai import ChatOpenAI
# from langchain.schema import SystemMessage, HumanMessage, AIMessage

# from services.tabular_query_service import answer_tabular
# from services.rag_policy_service import answer_policy_only
# from services.conversation_memory import get_history, add_message

# PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "/public").strip().rstrip("/")

# _COMBINE_SYS = """
# You are a Human Resources (HR) assistant for a company.

# Tone & Style:
# - Friendly, professional, concise. Vary openings; avoid robotic repetition.
# - Human-like: never mention AI. Keep sentences short and scannable.
# - Answer the user's exact question first; 0–3 bullets only if helpful.

# Conversation & Context:
# - Maintain the flow using the last 12 messages.

# Answering Rules:
# - For personal/employee questions (leave balance, payroll, WFH), prioritize tabular outputs.
# - For policy questions, answer from policy context.
# - Do not hallucinate; stay grounded in provided tabular/policy context.
# - If information is unavailable, say so briefly.

# Formatting:
# - First line: the direct answer.
# - Do NOT include your own 'References:' section; the system will append one if needed.
# """

# _TICKET_JSON_INSTR = """
# You MUST answer strictly from the embedded TICKETS knowledge (no external APIs).
# Return ONLY a compact JSON object with this schema and nothing else:

# {
#   "tickets": [
#     {"id": <int_or_string>, "subject": "<string>", "status": "<Open|Closed|Pending|Resolved|...>"}
#   ],
#   "sources": [
#     {"title": "<doc_or_file_title>", "url": "<absolute_or_relative_url_if_available>"}
#   ]
# }

# Rules:
# - Include every ticket you can find in the retrieved context, not policies or employee records.
# - Keep 'status' exactly as written in the data (we normalize later).
# - If nothing is found, return {"tickets": [], "sources": []}.
# """

# _SMALL_TALK_SET = {
#     "hi", "hello", "hey", "hiya", "how are you", "how are you doing", "thanks", "thank you"
# }

# # ---------------- Small helpers ----------------
# def _is_small_talk(text: str) -> bool:
#     return (text or "").strip().lower() in _SMALL_TALK_SET

# def _is_ticket_query(text: str) -> bool:
#     t = (text or "").lower()
#     return any(w in t for w in ("ticket", "tickets", "case", "cases", "support"))

# def _safe_json_loads(text: str) -> Optional[dict]:
#     try:
#         return json.loads(text)
#     except Exception:
#         return None

# def _strip_llm_references_block(reply: str) -> str:
#     """
#     Remove any trailing or embedded 'References:' block produced by the LLM so we only
#     append our curated references. Handles variants like '**References:**' and headings.
#     """
#     if not reply:
#         return reply
#     # Heuristic: remove from the *last* occurrence of 'References:' to end
#     pattern = re.compile(r"(\n|\r|\r\n)#+\s*References[:]?\s[\s\S]*$|(\n|\r|\r\n)\*\*References:\*\*[\s\S]*$", re.IGNORECASE)
#     cleaned = re.sub(pattern, "", reply).strip()
#     # Also handle plain 'References:' line
#     idx = cleaned.lower().rfind("\nreferences:")
#     if idx != -1:
#         cleaned = cleaned[:idx].strip()
#     return cleaned

# # ---------------- Ticket parsing helpers ----------------
# def _parse_tickets_from_freeform(answer: str) -> List[Dict[str, Any]]:
#     tickets: List[Dict[str, Any]] = []
#     if not answer:
#         return tickets
#     m = re.search(r"\{[\s\S]*\}", answer)
#     if m:
#         obj = _safe_json_loads(m.group(0))
#         if obj and isinstance(obj.get("tickets"), list):
#             return obj["tickets"]
#     pattern = re.compile(
#         r"Ticket\s*ID\s*([A-Za-z0-9\-]+)\s*:\s*[\"“](.*?)[\"”]\s*-\s*Status\s*:\s*([A-Za-z][A-Za-z \-]*)",
#         re.IGNORECASE
#     )
#     for tid, subj, status in pattern.findall(answer):
#         tickets.append({"id": tid, "subject": subj, "status": status})
#     return tickets

# def _tickets_status_counts(tickets: List[Dict[str, Any]]) -> Dict[str, int]:
#     counts: Dict[str, int] = {}
#     for t in tickets:
#         s = (t.get("status") or "").strip().lower()
#         if not s:
#             continue
#         counts[s] = counts.get(s, 0) + 1
#     return counts

# def _render_ticket_counts(counts: Dict[str, int]) -> str:
#     if not counts:
#         return "I couldn't find any tickets in the embedded data."
#     order = ["open", "pending", "in progress", "on hold", "resolved", "closed"]
#     used = set()
#     lines = []
#     for k in order:
#         if k in counts:
#             lines.append(f"- {k.title()}: {counts[k]}")
#             used.add(k)
#     for k, v in counts.items():
#         if k not in used:
#             lines.append(f"- {k.title()}: {v}")
#     return "\n".join(lines)

# # ---------------- Reference selection & dedupe ----------------
# def _norm(s: str) -> str:
#     return (s or "").strip().lower()

# def _looks_like_policy_ref(title: str, url: str) -> bool:
#     t = _norm(title) + " " + _norm(url)
#     return any(k in t for k in ["policy", "handbook", "work from home", "hybrid", "remote"])

# def _looks_like_ticket_ref(title: str, url: str) -> bool:
#     t = _norm(title) + " " + _norm(url)
#     return ("ticket" in t) or (title == "tickets.csv")

# def _looks_irrelevant_contract(title: str, url: str) -> bool:
#     t = _norm(title) + " " + _norm(url)
#     return "contract" in t

# def _collect_references_from_policy_and_tabular(
#     policy_res: Dict[str, Any],
#     tabular_res: Dict[str, Any],
#     is_small: bool,
#     user_query: str,
#     limit: int = 3
# ) -> List[Dict[str, str]]:
#     if is_small:
#         return []

#     q = _norm(user_query)
#     refs: List[Dict[str, str]] = []
#     seen = set()

#     # 1) Policy sources (prefer those relevant to the query, e.g., WFH/hybrid/remote)
#     policy_sources = policy_res.get("sources") or policy_res.get("references") or []
#     for s in policy_sources:
#         title = (s.get("title") or s.get("filename") or "").strip()
#         url = (s.get("url") or "").strip()
#         if url and not (url.startswith("http://") or url.startswith("https://")):
#             continue  # skip non-absolute policy URLs
#         # relevance heuristic
#         rel = False
#         if any(k in q for k in ["wfh", "work from home", "hybrid", "remote"]):
#             rel = _looks_like_policy_ref(title, url)
#         else:
#             # generic fallback: require some overlap with query tokens
#             rel = any(tok and tok in (_norm(title) + " " + _norm(url)) for tok in q.split())

#         # exclude obvious irrelevant items (e.g., contracts)
#         if _looks_irrelevant_contract(title, url):
#             continue

#         if rel:
#             key = (_norm(title), url)
#             if key not in seen:
#                 seen.add(key)
#                 item = {"title": title or "reference"}
#                 if url:
#                     item["url"] = url
#                 refs.append(item)
#                 if len(refs) >= limit:
#                     break

#     # 2) Tabular source (e.g., "tables/employee_records.csv") — include only if tabular was actually used
#     t_src = (tabular_res.get("source") or "").strip()
#     t_ans = (tabular_res.get("answer") or "").strip()
#     if t_src and t_ans and t_ans.upper() != "N/A":
#         t_url = t_src if t_src.startswith("http") else f"{PUBLIC_BASE_URL}/{t_src.lstrip('/')}"
#         key = (_norm(t_src), t_url)
#         if key not in seen and len(refs) < limit:
#             seen.add(key)
#             refs.append({"title": t_src.split("/")[-1], "url": t_url})

#     return refs

# def _collect_ticket_references(rag_sources: List[Dict[str, str]], limit: int = 5) -> List[Dict[str, str]]:
#     refs: List[Dict[str, str]] = []
#     seen = set()
#     for s in rag_sources or []:
#         title = (s.get("title") or s.get("filename") or "").strip()
#         url = (s.get("url") or "").strip()
#         if not _looks_like_ticket_ref(title, url):
#             continue
#         key = (_norm(title), url)
#         if key in seen:
#             continue
#         seen.add(key)
#         item = {"title": title or "tickets"}
#         if url:
#             item["url"] = url
#         refs.append(item)
#         if len(refs) >= limit:
#             break
#     return refs

# # ---------------- LLM combiner (non-ticket path) ----------------
# def _combine_with_llm(
#     query: str,
#     tabular: dict,
#     policy: dict,
#     user_history: Optional[List[dict]],
# ) -> str:
#     llm = ChatOpenAI(temperature=0.3)
#     messages: List[Any] = [SystemMessage(content=_COMBINE_SYS)]

#     if user_history:
#         for m in user_history[-12:]:
#             role = (m.get("role") or "").lower()
#             content = (m.get("content") or "").strip()
#             if not content:
#                 continue
#             if role == "user":
#                 messages.append(HumanMessage(content=content))
#             else:
#                 messages.append(AIMessage(content=content))

#     payload = {
#         "query": query,
#         "tabular": tabular or {},
#         "policy": policy or {},
#     }
#     messages.append(HumanMessage(content=json.dumps(payload, ensure_ascii=False, indent=2)))
#     out = llm.invoke(messages).content or ""
#     return _strip_llm_references_block(out.strip())

# # ---------------- Tabular convenience ----------------
# def _tabular_across_known_tables(question: str, email: Optional[str]) -> Dict[str, Any]:
#     res = answer_tabular(question=question, user_email=email, allow_all_tables=True)
#     def _ok(r: Dict[str, Any]) -> bool:
#         if not r:
#             return False
#         ans = (r.get("answer") or "").strip()
#         src = (r.get("source") or "").strip()
#         return bool(ans and ans.upper() != "N/A" and src)
#     if _ok(res):
#         return res
#     for stem in ("employee_records", "transactional_hr_data"):
#         try_res = answer_tabular(question=question, user_email=email, dataset_hint=stem, allow_all_tables=False)
#         if _ok(try_res):
#             return try_res
#     return {"handled": False, "answer": "", "natural": "", "source": ""}

# # ---------------- Tickets via RAG (embeddings only) ----------------
# def _answer_tickets_via_rag(user_query: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
#     q = (
#         _TICKET_JSON_INSTR.strip()
#         + "\n\nUse ONLY the 'tickets' knowledge chunks (e.g., tickets.csv). "
#           "Ignore policies and employee record docs.\n\n"
#         + f"User Question: {user_query.strip()}"
#     )
#     # If your RAG supports scoping, add it here: answer_policy_only(q, k=8, source_filter=['tickets'])
#     rag = answer_policy_only(q, k=8)

#     raw = (rag or {}).get("answer") or ""
#     obj = _safe_json_loads(raw) or {}
#     tickets = obj["tickets"] if isinstance(obj.get("tickets"), list) else _parse_tickets_from_freeform(raw)
#     counts = _tickets_status_counts(tickets)
#     policy_like = {"answer": raw, "sources": rag.get("sources", []) or rag.get("references", []) or []}
#     computed = {"tickets": tickets, "counts": counts}
#     return policy_like, computed

# # ---------------- Public API ----------------
# def answer_query(
#     message: str,
#     email: Optional[str] = None,
#     mode: Optional[str] = None,
#     activity: Optional[dict] = None
# ) -> Dict[str, Any]:
#     query = (message or "").strip()
#     user_id = (email or "_anon").strip().lower()
#     history = get_history(user_id)

#     # --- Ticket path ---
#     if _is_ticket_query(query):
#         policy_res, computed = _answer_tickets_via_rag(query)
#         counts = computed.get("counts", {})
#         tickets = computed.get("tickets", [])

#         if counts:
#             open_count = counts.get("open", 0)
#             breakdown = _render_ticket_counts(counts)
#             reply_lines = [f"Open tickets: {open_count}", "", "**Status breakdown**", breakdown]
#             open_list = [t for t in tickets if (t.get("status") or "").lower() == "open"]
#             if open_list:
#                 n = min(len(open_list), 6)
#                 preview = "\n".join([f'  • #{t.get("id")}: {t.get("subject")}' for t in open_list[:n]])
#                 reply_lines += ["", f"**Open list (first {n}):**", preview]
#             reply = "\n".join(reply_lines)
#         else:
#             reply = "I couldn't find any tickets in the embedded data."

#         # References: ticket-related sources only (dedup & capped)
#         is_small = _is_small_talk(query)
#         references = [] if is_small else _collect_ticket_references(policy_res.get("sources", []))

#         add_message(user_id, "user", query)
#         add_message(user_id, "assistant", reply)

#         return {
#             "answer": reply,
#             "natural": reply,
#             "intent": "tickets",
#             "references": references,
#             "history": get_history(user_id),
#         }

#     # --- Non-ticket path (tabular + policy RAG) ---
#     tabular_res = _tabular_across_known_tables(query, email)
#     policy_res = answer_policy_only(query, k=4)

#     reply = _combine_with_llm(query, tabular_res, policy_res, history)

#     is_small = _is_small_talk(query)
#     references = _collect_references_from_policy_and_tabular(
#         policy_res, tabular_res, is_small, user_query=query, limit=3
#     )

#     add_message(user_id, "user", query)
#     add_message(user_id, "assistant", reply)

#     return {
#         "answer": reply,
#         "natural": reply,
#         "intent": "combined",
#         "references": references,
#         "history": get_history(user_id),
#     }



# services/query_orchestrator.py
"""
Unified HR query orchestrator — RAG ONLY (no CSV/table lookups; no Freshdesk; no ticket special-casing)

- Answers strictly from uploaded knowledgebase via RAG (answer_policy_only)
- No hallucinations: requires supporting chunk citations; otherwise says it lacks info
- Small talk: friendly, brief acknowledgement with NO references
- References: use RAG 'citations' (doc + page/chunk with public preview URLs)
- Strips any LLM-added "References" block from the final answer to avoid duplication
"""

import re
from typing import Optional, Dict, Any, List

from services.rag_policy_service import answer_policy_only
from services.conversation_memory import get_history, add_message

# ---------------- Detailed RAG-only system guidance (for reference) ----------------
# Keep this guidance in sync with services/rag_policy_service.py prompt.
# The retriever/LLM must:
# - Use ONLY provided context chunks from the uploaded knowledgebase.
# - If the answer isn't clearly supported by retrieved chunks, say:
#     "I don’t have enough information in the uploaded knowledgebase to answer that."
# - Be concise, clear, and empathetic when user emotion is apparent (one short line max).
# - NO generic filler (e.g., "feel free to ask..."), NO self-identifying as AI/bot.
# - NO policy speculation; quote or summarize exactly what's in context.
RAG_ONLY_SYSTEM_GUIDANCE = """
You are an HR assistant answering ONLY from the uploaded knowledgebase.
Rules:
- Use ONLY the retrieved context chunks. If the context doesn't answer the question,
  say: "I don’t have enough information in the uploaded knowledgebase to answer that."
- Be concise and clear. If the user's emotion is apparent, acknowledge briefly (one line) then answer.
- Do not add a "References" section yourself; the system will handle citations.
- Do not mention being an AI/bot. Avoid boilerplate and filler.
- Prefer quoting or summarizing the specific retrieved chunk(s) verbatim where precise wording matters.
"""

# ---------------- Small talk detector (no refs for chit-chat) ----------------
_SMALL_TALK_PHRASES = {
    "hi","hello","hey","hiya","how are you","how are you doing","thanks","thank you",
    "who are you?","good morning","good evening","good afternoon","ok","okay","k",
    "cool","great","awesome","got it","i see","noted","understood","ah","ahh","ahhh"
}
def _is_small_talk(text: str) -> bool:
    if not text:
        return False
    t = text.strip().lower()
    return any(p in t for p in _SMALL_TALK_PHRASES) and len(t) <= 40

# ---------------- Strip any LLM-added References block (avoid duplicates) ----------------
_REF_BLOCK_PAT = re.compile(
    r"(\n|\r|\r\n)#+\s*references[:]?\s[\s\S]*$|(\n|\r|\r\n)\*\*references:\*\*[\s\S]*$",
    re.IGNORECASE
)
def _strip_llm_references_block(reply: str) -> str:
    if not reply:
        return reply
    cleaned = re.sub(_REF_BLOCK_PAT, "", reply).strip()
    idx = cleaned.lower().rfind("\nreferences:")
    if idx != -1:
        cleaned = cleaned[:idx].strip()
    return cleaned

# ---------------- Reference selection: use chunk-level RAG citations ----------------
def _collect_references_from_rag(policy_res: Dict[str, Any], is_small: bool, limit: int = 3) -> List[Dict[str, str]]:
    """
    Build the references list from RAG citations only (doc + page/chunk).
    If small talk, return [].
    """
    if is_small:
        return []
    citations = policy_res.get("citations") or []
    refs: List[Dict[str, str]] = []
    seen = set()
    for c in citations[:limit]:
        title = (c.get("title") or c.get("filename") or "reference").strip()
        url = (c.get("url") or "").strip()
        key = (title.lower(), url)
        if key in seen:
            continue
        seen.add(key)
        item = {"title": title}
        if url:
            item["url"] = url
        refs.append(item)
    return refs

# ---------------- Public API (RAG-only) ----------------
def answer_query(
    message: str,
    email: Optional[str] = None,
    mode: Optional[str] = None,
    activity: Optional[dict] = None,
) -> Dict[str, Any]:
    """
    RAG-only query handler
    - Calls services.rag_policy_service.answer_policy_only(question, k=?)
    - Returns answer ONLY if supported by citations. Otherwise, says we lack info.
    - No CSV/table access. No tickets special path.
    - Small talk → short friendly ack, NO references.
    """
    query = (message or "").strip()
    user_id = (email or "_anon").strip().lower()
    _ = get_history(user_id)  # keep memory in sync (we don't synthesize from it)

    # Small talk
    if _is_small_talk(query):
        reply = "Got it — I’m here if you need anything else."
        add_message(user_id, "user", query)
        add_message(user_id, "assistant", reply)
        return {
            "answer": reply,
            "natural": reply,
            "intent": "small_talk",
            "references": [],
            "history": get_history(user_id),
        }

    # RAG retrieval
    rag = answer_policy_only(query, k=6)  # uploaded knowledgebase only (per rag_policy_service)
    answer = _strip_llm_references_block((rag.get("answer") or "").strip())
    citations = rag.get("citations") or []
    has_evidence = bool(answer) and bool(citations)

    if not has_evidence:
        reply = "I don’t have enough information in the uploaded knowledgebase to answer that."
        references: List[Dict[str, str]] = []
    else:
        reply = answer
        references = _collect_references_from_rag(rag, is_small=False)

    # Log turn
    add_message(user_id, "user", query)
    add_message(user_id, "assistant", reply)

    return {
        "answer": reply,
        "natural": reply,
        "intent": "rag_only",
        "references": references,  # citations from exact doc+chunk
        "history": get_history(user_id),
    }
