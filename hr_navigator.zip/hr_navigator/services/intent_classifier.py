def detect_intent(message: str) -> str:
    message = message.lower()
    if "vacation" in message or "holiday" in message:
        return "personal_hr_data"
    if "ticket" in message or "status" in message:
        return "ticket_status"
    return "hr_policy"
