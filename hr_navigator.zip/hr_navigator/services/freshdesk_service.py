# services/freshdesk_service.py
"""
Freshdesk integration (API-key based, no email filtering)

Exports:
- fetch_all_tickets(include_conversations=False, per_page=100, max_pages=None) -> List[dict]
- summarize_tickets_for_chat(tickets: List[dict]) -> str
- export_tickets_with_links(include_conversations=True,
                            out_full_jsonl="tickets_full.jsonl",
                            out_refs_json="tickets_references.json") -> Dict[str, str]
"""

import os
import sys
import time
import json
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse
from datetime import datetime
from pathlib import Path

import requests
from dotenv import load_dotenv, find_dotenv

# ---------- Load env ----------
load_dotenv(find_dotenv(usecwd=True), override=False)

# ---------- Config ----------
def _require_env(name: str) -> str:
    v = os.getenv(name, "").strip()
    if not v:
        sys.exit(f"Missing env var: {name}")
    return v

def _build_api_base(domain: str) -> str:
    """
    Accepts 'acme', 'acme.freshdesk.com', or 'https://acme.freshdesk.com'
    -> 'https://acme.freshdesk.com/api/v2'
    """
    d = domain.strip()
    if d.lower().startswith("http"):
        parsed = urlparse(d)
        host = (parsed.netloc or parsed.path).strip("/")
    else:
        host = d.strip("/")
    if not host.endswith(".freshdesk.com"):
        host = f"{host}.freshdesk.com"
    return f"https://{host}/api/v2"

def _build_agent_base(domain: str) -> str:
    """
    -> 'https://acme.freshdesk.com/a'
    """
    d = domain.strip()
    if d.lower().startswith("http"):
        parsed = urlparse(d)
        host = (parsed.netloc or parsed.path).strip("/")
    else:
        host = d.strip("/")
    if not host.endswith(".freshdesk.com"):
        host = f"{host}.freshdesk.com"
    return f"https://{host}/a"

FRESHDESK_DOMAIN = _require_env("FRESHDESK_DOMAIN")
FRESHDESK_API_KEY = _require_env("FRESHDESK_API_KEY")
FRESHDESK_TIMEOUT_SECONDS = int(os.getenv("FRESHDESK_TIMEOUT_SECONDS", "30"))

API_BASE = _build_api_base(FRESHDESK_DOMAIN)
AGENT_BASE = _build_agent_base(FRESHDESK_DOMAIN)

# Public base URL (for downloadable links)
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "/public").strip().rstrip("/")

# Project dirs
BASE_DIR = Path(__file__).resolve().parent.parent
PUBLIC_DIR = BASE_DIR / "public"
FILES_DIR = PUBLIC_DIR / "files"
FILES_DIR.mkdir(parents=True, exist_ok=True)

# ---------- Requests session ----------
_session = requests.Session()
_session.auth = (FRESHDESK_API_KEY, "X")  # API key as username, 'X' as password
_session.headers.update({"Content-Type": "application/json", "User-Agent": "hr-navigator/1.0"})

def _request(method: str, url: str, params: Optional[Dict] = None) -> requests.Response:
    """Basic retry for 429/5xx with backoff."""
    backoff = 1
    while True:
        resp = _session.request(method, url, params=params, timeout=FRESHDESK_TIMEOUT_SECONDS)
        if resp.status_code == 429:
            retry_after = int(resp.headers.get("Retry-After", backoff))
            time.sleep(max(1, retry_after))
            backoff = min(backoff * 2, 30)
            continue
        if 500 <= resp.status_code < 600:
            if backoff > 30:
                resp.raise_for_status()
            time.sleep(backoff)
            backoff = min(backoff * 2, 30)
            continue
        resp.raise_for_status()
        return resp

# ---------- Helpers ----------
_STATUS_MAP = {2: "Open", 3: "Pending", 4: "Resolved", 5: "Closed"}

def _status_name(status_value) -> str:
    try:
        i = int(status_value)
        return _STATUS_MAP.get(i, f"Status {i}")
    except Exception:
        return str(status_value or "Unknown")

def _iso_short(dt_str: Optional[str]) -> str:
    if not dt_str:
        return ""
    try:
        dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return dt_str

def _ticket_link(ticket_id: int) -> str:
    return f"{AGENT_BASE}/tickets/{ticket_id}"

# ---------- Paginators ----------
def _paginate_list_tickets(include: str = "requester,company", per_page: int = 100) -> Iterable[Dict]:
    """
    Iterate over ALL tickets via page/per_page.
    """
    page = 1
    while True:
        params = {"page": page, "per_page": per_page}
        if include:
            params["include"] = include
        resp = _request("GET", f"{API_BASE}/tickets", params=params)
        items = resp.json() if resp.text else []
        if not items:
            break
        for t in items:
            yield t
        page += 1

def _paginate_conversations(ticket_id: int, per_page: int = 100) -> List[Dict]:
    """
    Fetch all conversations (agent replies, requester replies, and notes).
    """
    out: List[Dict] = []
    page = 1
    while True:
        params = {"page": page, "per_page": per_page}
        resp = _request("GET", f"{API_BASE}/tickets/{ticket_id}/conversations", params=params)
        items = resp.json() if resp.text else []
        if not items:
            break
        out.extend(items)
        page += 1
    return out

# ---------- Public: fetch_all_tickets ----------
def fetch_all_tickets(
    include_conversations: bool = False,
    per_page: int = 100,
    max_pages: Optional[int] = None
) -> List[Dict]:
    """
    Pull ALL tickets (no email filter), API key scoped.
    Returns normalized list of tickets (optionally with conversations).
    """
    per_page = max(1, min(int(per_page or 100), 100))
    results: List[Dict] = []
    seen = 0
    page = 1

    for raw in _paginate_list_tickets(include="requester,company", per_page=per_page):
        tid = raw.get("id")
        item = {
            "id": tid,
            "subject": raw.get("subject") or "",
            "status": _status_name(raw.get("status")),
            "updated": raw.get("updated_at"),
            "created": raw.get("created_at"),
            "priority": raw.get("priority"),
            "group_id": raw.get("group_id"),
            "agent_id": raw.get("responder_id"),
            "requester_id": raw.get("requester_id"),
            "company_id": raw.get("company_id"),
            "link": _ticket_link(tid) if tid else None,
        }

        if include_conversations and tid:
            try:
                item["conversations"] = _paginate_conversations(int(tid))
            except Exception:
                item["conversations"] = []

        results.append(item)
        seen += 1

        # Max pages: inferred by item count, not explicit page var (we iterate generator)
        if max_pages is not None and seen >= (per_page * max_pages):
            break
        page += 1

    # Sort newest first by updated/created
    def _sort_key(x: Dict[str, any]):
        raw = x.get("updated") or x.get("created") or ""
        try:
            return datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except Exception:
            return datetime.min

    results.sort(key=_sort_key, reverse=True)
    return results

# ---------- Public: summarize_tickets_for_chat ----------
def summarize_tickets_for_chat(tickets: List[Dict]) -> str:
    """
    Friendly summary for chat UIs.

    Format:
      Ticket summary — Open: N, Pending: N, Resolved: N, Closed: N
      #12345 • Open • [Subject](https://.../a/tickets/12345) • Updated 2025-08-15 12:34
      #12344 • Pending • [Subject](https://.../a/tickets/12344) • Updated 2025-08-12 08:01
      ... (up to 5 lines)
    """
    if not tickets:
        return "I couldn’t find any tickets for your account."

    # Counts
    counts: Dict[str, int] = {}
    for t in tickets:
        s = str(t.get("status") or "Unknown").strip()
        counts[s] = counts.get(s, 0) + 1

    ordered = []
    for s in ["Open", "Pending", "Resolved", "Closed"]:
        if s in counts:
            ordered.append(f"{s}: {counts[s]}")
    for s, n in counts.items():
        if s not in {"Open", "Pending", "Resolved", "Closed"}:
            ordered.append(f"{s}: {n}")

    header = "Ticket summary — " + ", ".join(ordered) if ordered else "Ticket summary"

    # Sort & list top 5
    def _sort_key(x: Dict[str, any]):
        raw = x.get("updated") or x.get("created") or ""
        try:
            return datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except Exception:
            return datetime.min

    lines: List[str] = [header]
    for t in sorted(tickets, key=_sort_key, reverse=True)[:5]:
        tid = t.get("id")
        status = (t.get("status") or "Unknown").strip()
        subject = (t.get("subject") or "(no subject)").strip()
        link = (t.get("link") or "").strip()
        updated = _iso_short(t.get("updated") or t.get("created"))
        subj_disp = f"[{subject}]({link})" if link else subject
        if tid:
            lines.append(f"#{tid} • {status} • {subj_disp} • Updated {updated}")
        else:
            lines.append(f"{status} • {subj_disp} • Updated {updated}")

    return "\n".join(lines)

# ---------- Export helpers ----------
def _attachment_refs_from_conversations(conversations: List[Dict]) -> List[Dict]:
    """
    Collect minimal attachment references from conversations.
    Each: {name, size, content_type, url}
    """
    refs: List[Dict] = []
    for conv in conversations or []:
        atts = conv.get("attachments") or []
        if isinstance(atts, list):
            for a in atts:
                url = a.get("attachment_url") or a.get("url")
                if not url:
                    continue
                refs.append({
                    "name": a.get("name"),
                    "size": a.get("size"),
                    "content_type": a.get("content_type"),
                    "url": url,
                })
    return refs

def _build_reference_object(ticket: Dict) -> Dict:
    """
    Minimal link bundle for each ticket.
    """
    tid = ticket.get("id")
    if not tid:
        return {}
    ref = {
        "id": tid,
        "reference_link": f"{AGENT_BASE}/tickets/{tid}",
        "api_link": f"{API_BASE}/tickets/{tid}",
        "conversations_api_link": f"{API_BASE}/tickets/{tid}/conversations",
    }
    rid = ticket.get("requester_id")
    if rid:
        ref["requester_reference_link"] = f"{AGENT_BASE}/contacts/{rid}"
        ref["requester_api_link"] = f"{API_BASE}/contacts/{rid}"
    cid = ticket.get("company_id")
    if cid:
        ref["company_reference_link"] = f"{AGENT_BASE}/companies/{cid}"
        ref["company_api_link"] = f"{API_BASE}/companies/{cid}"
    # Attachments (if present on this ticket structure)
    convs = ticket.get("conversations")
    if isinstance(convs, list):
        ref["attachments"] = _attachment_refs_from_conversations(convs)
    return ref

def _public_file_url(filename: str) -> str:
    # Exposed as: {PUBLIC_BASE_URL}/files/<filename>
    return f"{PUBLIC_BASE_URL}/files/{filename}"

# ---------- Public: export_tickets_with_links ----------
def export_tickets_with_links(
    include_conversations: bool = True,
    out_full_jsonl: str = "tickets_full.jsonl",
    out_refs_json: str = "tickets_references.json",
) -> Dict[str, str]:
    """
    Fetch all tickets (optionally with conversations),
    write both a JSONL stream and a references JSON array,
    and return public URLs.
    """
    tickets = fetch_all_tickets(include_conversations=include_conversations, per_page=100)

    full_path = FILES_DIR / out_full_jsonl
    refs_path = FILES_DIR / out_refs_json

    # Write JSONL
    with open(full_path, "w", encoding="utf-8") as f:
        for t in tickets:
            f.write(json.dumps(t, ensure_ascii=False) + "\n")

    # Write references JSON
    refs: List[Dict] = []
    for t in tickets:
        r = _build_reference_object(t)
        if r:
            refs.append(r)
    with open(refs_path, "w", encoding="utf-8") as rf:
        rf.write(json.dumps(refs, ensure_ascii=False, indent=2))

    return {
        "full_url": _public_file_url(out_full_jsonl),
        "refs_url": _public_file_url(out_refs_json),
        "count": str(len(tickets)),
    }

# ---------- If run directly (manual export) ----------
if __name__ == "__main__":
    try:
        res = export_tickets_with_links(include_conversations=True)
        print("✅ Export complete")
        print("   • Tickets JSONL:", res.get("full_url"))
        print("   • References JSON:", res.get("refs_url"))
        print("   • Count:", res.get("count"))
    except requests.HTTPError as e:
        print("HTTP error:", getattr(e.response, "status_code", "?"), (e.response.text[:500] if e.response else ""))
    except Exception as e:
        print("Error:", e)
