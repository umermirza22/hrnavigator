import os
from dotenv import load_dotenv

load_dotenv()

FRESHDESK_DOMAIN = os.getenv("FRESHDESK_DOMAIN", "").strip()
FRESHDESK_API_KEY = os.getenv("FRESHDESK_API_KEY", "").strip()
FRESHDESK_TIMEOUT_SECONDS = int(os.getenv("FRESHDESK_TIMEOUT_SECONDS", "10"))

if not FRESHDESK_DOMAIN or not FRESHDESK_API_KEY:
    raise ValueError("Freshdesk config missing: set FRESHDESK_DOMAIN and FRESHDESK_API_KEY in .env")
